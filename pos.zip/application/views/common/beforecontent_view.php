<div id="wrapper">
	<div id="top">
		<div id="harga">
			<h1 id="total_harga">Rp. <span id="angka_total">192.000</span></h1>
			<div class="hasil_pembayaran"><label for="total_bayar" class="hasil_pembayaran_label" style="">Bayar</label><input maxlength="10" id="total_bayar" class="uang_pembayaran number_input" type="text" name="uang_bayar" /></div>
			<div class="hasil_pembayaran"><label for="total_kembalian" class="hasil_pembayaran_label" style="width:120px;display:inline-block">Kembalian</label><input maxlength="10" id="total_kembalian" class="uang_pembayaran number_input" type="text" name="uang_kembalian" /></div>
		</div>
		<div id="toko">
			<h2>MartOnline</h2>
			<address>Jl. zzz wwwww no. 10</address>
			<p>No : 13</p>
			<p>opertor : andhri</p>
		</div>
		<div class="clear"></div>
	</div>
	<div id="content">