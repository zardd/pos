<link rel="stylesheet" type="text/css" href="<?php echo base_url().'styles/main.css'; ?>" />
<link rel="stylesheet" type="text/css" href="<?php echo base_url().'styles/flick/jquery-ui-1.8.14.custom.css'; ?>" />

<script type="application/javascript">
	document.base_url = '<?php echo base_url(); ?>';
</script>

<script type="application/javascript" src="<?php echo base_url().'scripts/jquery-1.6.2.min.js'; ?>"></script>
<script type="application/javascript" src="<?php echo base_url().'scripts/minified/jquery.ui.core.min.js'; ?>"></script>
<script type="application/javascript" src="<?php echo base_url().'scripts/minified/jquery.ui.widget.min.js'; ?>"></script>
<script type="application/javascript" src="<?php echo base_url().'scripts/minified/jquery.ui.dialog.min.js'; ?>"></script>
<script type="application/javascript" src="<?php echo base_url().'scripts/minified/jquery.ui.autocomplete.min.js'; ?>"></script>
<script type="application/javascript" src="<?php echo base_url().'scripts/minified/jquery.ui.datepicker.min.js'; ?>"></script>
<script type="application/javascript" src="<?php echo base_url().'scripts/resizer/jquery.textarearesizer.compressed.js'; ?>"></script>
<script type="application/javascript" src="<?php echo base_url().'scripts/general.js'; ?>"></script>

