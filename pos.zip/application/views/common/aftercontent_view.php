     
	</div> <!--content-->
	<div id="footer">    
		<p><?php
			echo '<a href="'.base_url().'penjualan" class="footer_menu">F1-HELP</a> | 
			<a href="'.base_url().'penjualan" class="footer_menu">F2-PENJUALAN</a> | 
			<a href="'.base_url().'penjualan" class="footer_menu">F2-PENJUALAN</a> | 
			<a href="'.base_url().'penjualan" class="footer_menu">F2-PENJUALAN</a> | 
			<a href="'.base_url().'penjualan" class="footer_menu">F2-PENJUALAN</a> | 
			<a href="'.base_url().'penjualan" class="footer_menu">F2-PENJUALAN</a> | 
			<a href="'.base_url().'penjualan" class="footer_menu">F2-PENJUALAN</a>
			';
		?></p>
		<p><br />Page rendered in {elapsed_time} seconds with {memory_usage} memory usage</p>
	</div>
</div> <!--wrapper-->