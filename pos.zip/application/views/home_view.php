<?php $this->load->view('common/head') ?>
<!-- put script/style each page here befor any include-->
<?php $this->load->view('common/header') ?>
<!-- put script each page here after include-->
<?php $this->load->view('common/head_body') ?>	
<?php $this->load->view('common/beforecontent_view') ?>	
	<!--content goes here -->   					
	Isi  POS
	
	
	<!-- End of Content -->   					
<?php $this->load->view('common/aftercontent_view') ?>	
<?php $this->load->view('common/foot') ?>
    